export interface Noticia {
    id?: number;
    titulo: string;
    descricao: string;
}
